clear all;
close all;

%% add path of a folder including support functions
addpath('functions');

%% input image (scaling to [0,1])
I = imread('./images/m2.jpg');
imgs_rgb1 = generate_exosured_imgs(I);
imgs_rgb = im2double(imgs_rgb1);
img_result = mfusion(imgs_rgb);

figure;
imshow(img_result);


